""" This program can resize any image by using Python. Very simply I used this
    to make my image expand to 600 x 600.
    Dmitriy Kononenko 10/10/2024
"""
# import image by using PIL
from PIL import Image

"""Create a variable named img to Open your image ('Image.jpg') was used by me,
   however this can easily be replace by the image file of your chosing.    
"""
img = Image.open('Image.jpg')

# set the variables to new parameters for me it was 600 x 600. Can be changed
new_width = 600
new_height = 600

# This is the logic that uses those new parameters to resize an image
resized_img = img.resize((new_width, new_height))

# image will be saved as resized_img.jpg
resized_img.save('resized_image.jpg')

# close the image after complete.
img.close
